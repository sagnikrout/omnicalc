#!/bin/sh
set -eu
PREFIX="${PREFIX:-/usr/local}"
DEST="$PREFIX/bin"

if [ ! -w "$PREFIX" ] && [ "$(id -u)" -ne 0 ]; then
    echo "Error: cannot install to $DEST; choose a writable PREFIX or use sudo" >&2
    exit 1
fi
install -d "$DEST"
install -m 755 "$(dirname "$0")/omnicalc" "$DEST/omnicalc"
echo "omnicalc installed successfully to $DEST/omnicalc"
